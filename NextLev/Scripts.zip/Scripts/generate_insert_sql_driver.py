import yaml
import json
from typing import Dict, List
import sys
import dmv_schema_validation
from dmv_load_params import get_env_params
import dmv_functions
import os 

def get_val(v, current_level, logger):
    try:
        json_path = v['json_path']
        logger.debug("Processing JSON path: %s", json_path)
        parts = json_path.split(".")
        try:
            for part in parts:
                logger.debug("Accessing JSON level: %s", part)
                current_level = current_level.get(part)
            value = current_level
            logger.debug("Extracted value '%s' from JSON path '%s'", value, json_path)
        except AttributeError as e:
            logger.error("AttributeError while accessing JSON path '%s': %s", json_path, e)
            value = None
    except KeyError:
        value = v
        logger.debug("No 'json_path' in mapping, using direct value: %s", value)
    return value

def handle_values(item_data, logger):
    item_values = []
    logger.debug("Starting to handle values for item data: %s", item_data)
    for key, val in item_data.items():
        if val:
            if isinstance(val, str):
                repl = f"'{val}'"
                item_values.append(repl)
                logger.debug("Processed string value for '%s': %s", key, repl)
            elif isinstance(val, int):
                item_values.append(str(val))
                logger.debug("Processed int value for '%s': %s", key, val)
            elif isinstance(val, dict):
                if val.get('datatype') == "string":
                    repl = f"'{val['value']}'"
                    item_values.append(repl)
                    logger.debug("Processed dict string value for '%s': %s", key, repl)
                elif val.get('datatype') in ["datetime", "int"]:
                    repl = str(val['value'])
                    item_values.append(repl)
                    logger.debug("Processed dict %s value for '%s': %s", val['datatype'], key, repl)
                else:
                    logger.error("Unhandled datatype in constant parameters for '%s': %s", key, val)
                    raise Exception("Unhandled datatype of value in constant parameters")
            else:
                logger.error("Unhandled datatype for '%s': %s", key, type(val))
                raise Exception("Unhandled datatype of value")
        else:
            item_values.append("NULL")
            logger.debug("Set NULL for '%s' as value is None", key)
    logger.debug("Finished handling values, result: %s", item_values)
    return item_values

def generate_driver_insert(mapping: Dict, data: Dict, source_transaction_id, policy_trans_id, key="DMV_DRIVER", operation="insert_field_mapping", logger=None) -> List[str]:
    """Generate INSERT statements for DMV_DRIVER table."""
    insert_statements = []
    table_name = mapping[key]['table_name']
    logger.info("Generating INSERT statements for table '%s'", table_name)
    driver_list = data.get('registrantList', [])
    logger.debug("Processing driver list with %s entries", len(driver_list))

    def return_find_val(v):
        try:
            modified_path = v['json_path'].replace('registrantList[].', '')
            logger.debug("Modified JSON path from '%s' to '%s'", v['json_path'], modified_path)
            return {'json_path': modified_path}
        except KeyError:
            logger.debug("No modification needed for value: %s", v)
            return v
    
    values = []
    for i, driver in enumerate(driver_list):
        logger.info("Processing driver entry %s", i)
        driver_data = {k: get_val(return_find_val(v), driver, logger) 
                      for k, v in mapping[key][operation]['fields'].items()}
        logger.debug("Generated driver data: %s", driver_data)
        
        driver_data.update({"SOURCE_TRANS_ID": source_transaction_id})
        driver_data.update({"TRANS_ID": policy_trans_id})
        driver_columns = ', '.join([f'"{col}"' for col in driver_data.keys()])
        driver_values = handle_values(driver_data, logger)
        # insert_statement = f"INSERT INTO {table_name} ({driver_columns}) \nVALUES\n ({driver_values});"
        # insert_statements.append(insert_statement)
        values.append(f"({', '.join(driver_values)})")

    if values:
        val = ',\n'.join(values)
        insert_statement = f"INSERT INTO {table_name} ({driver_columns}) \nVALUES\n {val};"
        insert_statements.append(insert_statement)
        logger.debug("Generated bulk SQL statement: %s", insert_statement)
    else:
        logger.warning("No values generated for insertion")

    logger.info("Generated %s INSERT statements", len(insert_statements))
    return insert_statements

if __name__ == "__main__":
    try:
        script_directory = os.path.dirname(os.path.abspath(__file__))
        script_directory = script_directory.rstrip("/Scripts")
        env_params = get_env_params(script_directory)
        # Reading the arguments
        input_payload_json_file_name = sys.argv[1]
        input_payload_json = os.path.join(env_params['input_json_path'], input_payload_json_file_name)
        source_transaction_id = sys.argv[2]
        policy_trans_id = sys.argv[3]
        log_file = sys.argv[4]
        log_file_path = os.path.join(env_params['log_dir'], log_file)

        logger = dmv_functions.setup_logger(__name__, log_file_path)
        logger.info("Script execution started.")
        logger.debug("Environment parameters loaded: %s", env_params)

        logger.info("Input JSON file path: %s", input_payload_json)
        logger.info("Log file path: %s", log_file_path)

        logger.info("Loading input JSON from %s", input_payload_json)
        with open(input_payload_json, 'r') as json_file:
            data = json.load(json_file)
        logger.debug("Successfully loaded input data: %s", data)

        # Load YAML mapping
        mapping = dmv_functions.load_mapping_yaml(data, env_params, logger)
        logger.debug("Successfully loaded mapping: %s", mapping)

        driver_inserts = generate_driver_insert(mapping, data, source_transaction_id, policy_trans_id, logger=logger)

        for insert in driver_inserts:
            print(insert)
            logger.debug("Printed SQL statement: %s", insert)

        logger.info("Writing SQL statements to %s", log_file_path)
        logger.info('\n'.join(driver_inserts))

    except IndexError:
        print("Missing required command-line arguments.")
        raise
    except FileNotFoundError as e:
        print("File not found: %s", e)
        raise
    except json.JSONDecodeError as e:
        print("JSON decoding error: %s", e)
        raise
    except Exception as e:
        print("Script execution failed: %s", e)
        raise


