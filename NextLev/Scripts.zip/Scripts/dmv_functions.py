import logging
import yaml
import json 

def setup_console_logger(name, log_file_path):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)  # Set the base logging level

    # Avoid duplicate handlers if logger is already configured
    if not logger.handlers:
        # File handler: logs everything to a file
        file_handler = logging.FileHandler(log_file_path)
        file_handler.setLevel(logging.DEBUG)

        # Console handler: logs to stdout
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)  # You can tweak this

        # Format for both handlers
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)

        # Attach handlers to the logger
        logger.addHandler(file_handler)
        logger.addHandler(console_handler)

    return logger


def setup_logger(name, log_file_path):
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)  # Set the base logging level

    # Avoid duplicate handlers if logger is already configured
    if not logger.handlers:
        # File handler: logs everything to a file
        file_handler = logging.FileHandler(log_file_path)
        file_handler.setLevel(logging.DEBUG)

        # Format for both handlers
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(formatter)

        # Attach handlers to the logger
        logger.addHandler(file_handler)

    return logger

def load_struct_file(input_json, env_params, logger):
    legalType = input_json.get('legalType')
    if legalType:
        if legalType.upper() == "I":
            struct_file = env_params['structure_json_file']["I"]
        elif legalType.upper() == "B":
            struct_file = env_params['structure_json_file']["B"]
        else:
            logger.error("Unhandled legalType: %s", legalType)
            raise Exception("Unhandled legalType")
    else:
        raise Exception("No legalType present in the provided Json")
    
    logger.info("The legalType is %s; loading schema from %s", legalType, struct_file)
    with open(struct_file, 'r') as f:
        schema_json = json.load(f)
    return schema_json

def load_mapping_yaml(input_json, env_params, logger):
    legalType = input_json.get('legalType')
    if legalType:
        if legalType.upper() == "I":
            mapping_yaml = env_params['mapping_yaml_path']["I"]
        elif legalType.upper() == "B":
            mapping_yaml = env_params['mapping_yaml_path']["B"]
        else:
            logger.error("Unhandled legalType: %s", legalType)
            raise Exception("Unhandled legalType")
    else:
        raise Exception("No legalType present in the provided Json")
    
    logger.info("Loading mapping YAML from %s", mapping_yaml)
    with open(mapping_yaml, 'r') as yaml_file:
            mapping = yaml.safe_load(yaml_file)
    return mapping