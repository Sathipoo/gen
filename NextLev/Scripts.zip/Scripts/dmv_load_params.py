import os

def get_env_params(home_dir="/opt/iics/dev/Scripts/EDCP_dmv"):
    script_dir = home_dir+"/Scripts"
    parameter_dir = home_dir+"/Parameters"
    log_dir = home_dir+"/Logs"
    src_files_dir = home_dir+"/Srcfiles"
    tgt_files_dir = home_dir+"/Tgtfiles"


    mapping_business_yaml_path = os.path.join(parameter_dir,"dmv_field_mapping_business.yaml")
    mapping_individual_yaml_path = os.path.join(parameter_dir,"dmv_field_mapping_individual.yaml")
    input_json_path = tgt_files_dir
    tgt_sql_file = log_dir
    structure_business_json_file=os.path.join(parameter_dir,"dmv_reference_business_schema.json")
    structure_individual_json_file=os.path.join(parameter_dir,"dmv_reference_individual_schema.json")
    validation_flag = False

    return {
        "mapping_yaml_path":{"B":mapping_business_yaml_path, "I":mapping_individual_yaml_path}, 
        "input_json_path":input_json_path, 
        "tgt_sql_file":tgt_sql_file, 
        "structure_json_file":{"B":structure_business_json_file, "I":structure_individual_json_file}, 
        "validation_flag":validation_flag,
        "log_dir":log_dir
    }