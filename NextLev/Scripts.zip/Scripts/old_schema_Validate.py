import json
import sys
import os
from datetime import datetime
from dmv_load_params import get_env_params
import dmv_functions

def validate_schema(input_json, schema_json, logger):
    for key, schema_value in schema_json.items():
        if key not in input_json:
            logger.error("Validation Error: Key '%s' is missing in input JSON.", key)
            return False

        input_value = input_json[key]
        schema_type = type(schema_value)
        input_type = type(input_value)

        # if schema_type != input_type:
        #     logger.error(f"Validation Error: Key '{key}' type mismatch. Expected '{schema_type.__name__}', got '{input_type.__name__}'.")
        #     return False

        if isinstance(schema_value, dict):
            logger.info("Validating nested dictionary for key '%s'.", key)
            if not validate_schema(input_value, schema_value, logger):
                return False
        elif isinstance(schema_value, list):
            logger.info("Validating list for key '%s'.", key)
            if input_value:  # Check if input list is not empty
                if not isinstance(input_value, list):
                    logger.error("Validation Error: Key '%s' should be a list in input JSON.", key)
                    return False
                if schema_value:  # If schema list is not empty
                    for i, item in enumerate(input_value):
                        logger.info("Validating list item %s for key '%s'.", i, key)
                        if not validate_schema(item, schema_value[0], logger):
                            return False
            elif schema_value:  # Schema has list definition but input list is empty
                if not isinstance(input_value, list):
                    logger.error("Validation Error: Key '%s' should be a list in input JSON.", key)
                    return False
    return True

def main_validate(env_params, input_payload_json, logger):
    try:
        logger.info("Loading schema JSON from %s.", env_params['structure_json_file'])
        with open(env_params['structure_json_file'], 'r') as f:
            schema_json = json.load(f)

        logger.info("Loading input JSON from %s.", input_payload_json)
        with open(input_payload_json, 'r') as f:
            input_json = json.load(f)

        logger.info("Starting schema validation.")
        is_valid = validate_schema(input_json, schema_json, logger)
        return is_valid
    except FileNotFoundError as e:
        logger.error("File not found: %s", e)
        raise
    except json.JSONDecodeError as e:
        logger.error("JSON decoding error: %s", e)
        raise
    except Exception as e:
        logger.error("Unexpected error during validation: %s", e)
        raise

if __name__ == "__main__":
    try:
        sys0 = sys.argv[0]
        #home_dir = '/'.join(sys0.split("/")[:-2])
        script_directory = os.path.dirname(os.path.abspath(__file__))
        script_directory = script_directory.rstrip("/Scripts")
        env_params = get_env_params(script_directory)
    
        input_payload_json_file_name = sys.argv[1]
        input_payload_json = os.path.join(env_params['input_json_path'], input_payload_json_file_name)
        log_file = sys.argv[2]
        log_file_path = os.path.join(env_params['log_dir'], log_file)

        logger = dmv_functions.setup_console_logger(__name__, log_file_path)
        logger.info("Script execution started.")
        logger.info("Environment parameters loaded: %s", env_params)

        logger.info("Input JSON file path: %s", input_payload_json)

        is_valid = main_validate(env_params, input_payload_json, logger)
        
        if is_valid:
            logger.info("The provided JSON matches the schema.")
        else:
            logger.error("The provided JSON does not match the schema.")
            raise Exception("The provided JSONs do not match.")
            
    except IndexError:
        logger.error("Missing command-line argument for input JSON file.")
        raise
    except Exception as e:
        logger.exception("Script execution failed.")
        raise