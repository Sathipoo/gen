import json
import sys
import os
from datetime import datetime
# from dmv_load_params import get_env_params
import dmv_functions

def validate_schema(input_json, schema_json, logger):
    # Check all required fields in schema
    for key, schema_value in schema_json.items():
        # Check if the key is missing and required
        logger.info(f" --- {key} , {schema_value} ---")
        is_required = schema_value.get("isrequired") == "required"
        if key not in input_json:
            if is_required:
                logger.error("Validation Error: Required key '%s' is missing in input JSON.", key)
                return False
            continue  # Skip optional fields that are missing

        input_value = input_json[key]

        # Handle null values
        if input_value is None:
            if is_required:
                logger.error("Validation Error: Required key '%s' cannot be null.", key)
                return False
            continue  # Allow null for optional fields

        # Check if this is a primitive/array or a nested object
        if "type" in schema_value:
            schema_type = schema_value["type"].lower()  # e.g., "string", "number", "array"

            # Type validation
            if schema_type == "string":
                if not isinstance(input_value, str):
                    logger.error("Validation Error: Key '%s' type mismatch. Expected 'string', got '%s'.", key, type(input_value).__name__)
                    return False
            elif schema_type == "number":
                if not isinstance(input_value, (int, float)):
                    logger.error("Validation Error: Key '%s' type mismatch. Expected 'number', got '%s'.", key, type(input_value).__name__)
                    return False
            elif schema_type == "array":
                if not isinstance(input_value, list):
                    logger.error("Validation Error: Key '%s' should be an array in input JSON.", key)
                    return False
                # Validate array items if schema defines them
                if "items" in schema_value and input_value:  # Only validate if input list is non-empty
                    logger.info("Validating array items for key '%s'.", key)
                    for i, item in enumerate(input_value):
                        logger.info("Validating array item %s for key '%s'.", i, key)
                        if not validate_schema(item, schema_value["items"], logger):
                            return False
        else:
            # Nested object validation
            if not isinstance(input_value, dict):
                logger.error("Validation Error: Key '%s' should be an object in input JSON.", key)
                return False
            logger.info("Validating nested object for key '%s'.", key)
            if not validate_schema(input_value, schema_value, logger):
                return False

    return True

def main_validate(env_params, input_payload_json, logger):
    try:
        logger.info("Loading schema JSON from %s.", env_params['structure_json_file'])
        with open(env_params['structure_json_file'], 'r') as f:
            schema_json = json.load(f)

        logger.info("Loading input JSON from %s.", input_payload_json)
        with open(input_payload_json, 'r') as f:
            input_json = json.load(f)

        logger.info("Starting schema validation.")
        is_valid = validate_schema(input_json, schema_json, logger)
        return is_valid
    except FileNotFoundError as e:
        logger.error("File not found: %s", e)
        raise
    except json.JSONDecodeError as e:
        logger.error("JSON decoding error: %s", e)
        raise
    except Exception as e:
        logger.error("Unexpected error during validation: %s", e)
        raise

if __name__ == "__main__":
    try:
        script_directory = os.path.dirname(os.path.abspath(__file__))
        script_directory = script_directory.rstrip("/Scripts")
        # env_params = get_env_params(script_directory)
        env_params = {
            "input_json_path" : "/Users/sathishkumar/AllFiles/miami/krishna_sql_gen/grokk/nextlev/",
            "structure_json_file" : "/Users/sathishkumar/AllFiles/miami/krishna_sql_gen/grokk/nextlev/struct.json",
            "log_dir": "/Users/sathishkumar/AllFiles/miami/krishna_sql_gen/grokk/nextlev/logs/"
        }
    
        input_payload_json_file_name = "input_json.json"
        input_payload_json = os.path.join(env_params['input_json_path'], input_payload_json_file_name)
        log_file = "sample_log.log"
        log_file_path = os.path.join(env_params['log_dir'], log_file)

        logger = dmv_functions.setup_console_logger(__name__, log_file_path)
        logger.info("Script execution started.")
        logger.info("Environment parameters loaded: %s", env_params)

        logger.info("Input JSON file path: %s", input_payload_json)

        is_valid = main_validate(env_params, input_payload_json, logger)
        
        if is_valid:
            logger.info("The provided JSON matches the schema.")
        else:
            logger.error("The provided JSON does not match the schema.")
            raise Exception("The provided JSONs do not match.")
            
    except IndexError:
        logger.error("Missing command-line argument for input JSON file.")
        raise
    except Exception as e:
        logger.exception("Script execution failed.")
        raise